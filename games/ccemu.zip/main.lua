-- PaloEmu PC: abre la ROM de la raiz y la ejecuta. Sin menus. F11 = pantalla completa, Esc = salir.
local bit, ffi = require("bit"), require("ffi")
local NES, Retro = require("nes"), require("retro")
local bor, lshift = bit.bor, bit.lshift
local CORES = {
  snes = Retro({ id = "snes", hints = { "snes", "bsnes" }, bare = "snes9x_libretro", path = "game.sfc", aspect = 4 / 3, fps = 60.0988 }),
  n64 = Retro({ id = "n64", hints = { "mupen", "parallel", "n64" }, bare = "mupen64plus_next_libretro", path = "game.z64", aspect = 4 / 3, fps = 60, nodev = false,
    vars = { ["mupen64plus-rdp-plugin"] = "angrylion", ["mupen64plus-rsp-plugin"] = "hle", ["mupen64plus-cpucore"] = "dynamic_recompiler",
      ["mupen64plus-43screensize"] = "320x240", ["mupen64plus-Framerate"] = "Fullspeed", ["mupen64plus-angrylion-multithread"] = "all threads",
      ["parallel-n64-gfxplugin"] = "angrylion", ["parallel-n64-rspplugin"] = "hle" } }),
  gba = Retro({ id = "gba", hints = { "mgba", "gpsp", "vba", "gba" }, bare = "mgba_libretro", path = "game.gba", aspect = 1.5, fps = 59.7275 }),
}
local EXT = { nes = "nes", sfc = "snes", smc = "snes", swc = "snes", fig = "snes", z64 = "n64", n64 = "n64", v64 = "n64", gba = "gba" }
local NMAP = { { "a", 1 }, { "b", 2 }, { "sel", 4 }, { "sta", 8 }, { "up", 16 }, { "down", 32 }, { "left", 64 }, { "right", 128 } }
local SMAP = { { "b", 0 }, { "y", 1 }, { "sel", 2 }, { "sta", 3 }, { "up", 4 }, { "down", 5 }, { "left", 6 }, { "right", 7 }, { "a", 8 }, { "x", 9 }, { "l", 10 }, { "r", 11 } }
local M64 = { { "b", 1 }, { "a", 0 }, { "sta", 3 }, { "l", 10 }, { "r", 11 }, { "z", 12 } }
local KEYS = { up = "up", down = "down", left = "left", right = "right", a = "x", b = "z", x = "s", y = "a", l = "q", r = "w", z = "c",
  sta = "return", sel = "rshift", cu = "i", cd = "k", cl = "j", cr = "l" }

local sys, core, romName, msg, acc = nil, nil, nil, nil, 0
local P, img, imgdata, sdata, src, quad = {}, nil, nil, nil, nil, nil

local function findRom()
  local a = arg and arg[2]
  if a and not a:match("^%-") then return a end
  local lf, dirs, seen = love.filesystem, {}, {}
  for _, d in ipairs({ lf.getSource(), lf.getSourceBaseDirectory(), lf.getWorkingDirectory(), ".", lf.getSaveDirectory() }) do
    d = d:gsub("\\", "/"):gsub("/$", "")
    if not seen[d] then seen[d] = 1; dirs[#dirs + 1] = d end
  end
  for _, d in ipairs(dirs) do
    for e in pairs(EXT) do
      local p = d .. "/rom." .. e
      local f = io.open(p, "rb")
      if f then f:close(); return p end
    end
  end
  for e in pairs(EXT) do if lf.getInfo("rom." .. e) then return "rom." .. e, false end end
end

local function readAll(p, abs)
  if not abs then return love.filesystem.read(p) end
  local f = io.open(p, "rb"); if not f then return end
  local d = f:read("*a"); f:close(); return d
end

local function savePath(e) return "saves/" .. romName .. e end
local function saveSram()
  if not (romName and core) then return end
  love.filesystem.createDirectory("saves")
  local s
  if sys == "nes" then s = NES.battery and NES.getSram() elseif core.loaded then s = core.getSram() end
  if s then love.filesystem.write(savePath(".sav"), s) end
end

local function start(path, abs)
  local name = path:match("([^/\\]+)$")
  local e = name:match("%.(%w+)$")
  sys = e and EXT[e:lower()]
  if not sys then msg = "Formato no soportado: " .. name return end
  local data = readAll(path, abs)
  if not data then msg = "No se pudo leer " .. path return end
  romName = name
  local sv = love.filesystem.read(savePath(".sav"))
  if sys == "nes" then
    local ok, err = NES.load(data)
    if not ok then msg = tostring(err) return end
    if sv and NES.battery then NES.setSram(sv) end
    core = NES
  else
    local c = CORES[sys]
    local ok, err = pcall(c.load, data)
    if not ok then msg = tostring(err) return end
    if sv then c.setSram(sv) end
    core = c
  end
  love.window.setTitle("PaloEmu - " .. name)
end

function love.load()
  love.graphics.setBackgroundColor(0, 0, 0)
  love.window.setFullscreen(true, "desktop")
  love.mouse.setVisible(false)
  imgdata = love.image.newImageData(256, 240)
  NES.setBuffer(ffi.cast("uint32_t*", imgdata:getFFIPointer()))
  sdata = love.sound.newSoundData(735, 44100, 16, 1)
  NES.setAudio(ffi.cast("int16_t*", sdata:getFFIPointer()))
  src = love.audio.newQueueableSource(44100, 16, 1, 6)
  img = love.graphics.newImage(imgdata); img:setFilter("nearest", "nearest")
  quad = love.graphics.newQuad(0, 8, 256, 224, 256, 240)
  local p = findRom()
  if p then start(p, not love.filesystem.getInfo(p)) else msg = "No encuentro rom.nes / rom.sfc / rom.smc / rom.gba / rom.z64 / rom.n64\nponla junto al emulador.   Esc: salir" end
end

local function mask(map, shift)
  local m = 0
  for i = 1, #map do if P[map[i][1]] then m = bor(m, shift and lshift(1, map[i][2]) or map[i][2]) end end
  return m
end

function love.update(dt)
  if not core then return end
  local k = love.keyboard.isDown
  for n, key in pairs(KEYS) do P[n] = k(key) end
  local jy = love.joystick.getJoysticks()[1]
  if jy and jy:isGamepad() then
    local g = function(b) return jy:isGamepadDown(b) end
    P.up = P.up or g("dpup"); P.down = P.down or g("dpdown"); P.left = P.left or g("dpleft"); P.right = P.right or g("dpright")
    P.a = P.a or g("b"); P.b = P.b or g("a"); P.x = P.x or g("y"); P.y = P.y or g("x")
    P.l = P.l or g("leftshoulder"); P.r = P.r or g("rightshoulder"); P.sta = P.sta or g("start"); P.sel = P.sel or g("back")
  end
  local snes = sys ~= "nes"
  local step = 1 / (snes and core.fps or 60)
  acc = math.min(acc + dt, 0.1)
  local n = 0
  while acc >= step and n < 3 do
    local skip = acc >= 2 * step
    if snes then
      if sys == "n64" then
        local sx = (P.right and 1 or 0) - (P.left and 1 or 0)
        local sy = (P.down and 1 or 0) - (P.up and 1 or 0)
        core.setMask(mask(M64, true))
        core.setAnalog(sx * 32767, sy * 32767, ((P.cr and 1 or 0) - (P.cl and 1 or 0)) * 32767, ((P.cd and 1 or 0) - (P.cu and 1 or 0)) * 32767)
      else core.setMask(mask(SMAP, true)) end
      core.frame(skip)
    else
      NES.buttons = mask(NMAP, false); NES.frame(skip)
      if src:getFreeBufferCount() > 0 then src:queue(sdata) end
      if not src:isPlaying() then src:play() end
    end
    acc = acc - step; n = n + 1
  end
  if acc >= step then acc = 0 end
  if n > 0 and not snes then img:replacePixels(imgdata) end
  if snes then
    core.sramT = (core.sramT or 0) + dt
    if core.sramT > 10 and sys ~= "n64" then core.sramT = 0; saveSram() end
  end
end

function love.draw()
  local W, H = love.graphics.getDimensions()
  if core and love.timer.getTime() < 4 then love.graphics.setColor(1,1,1,0.7); love.graphics.print("Esc: salir   F11: ventana", 8, 8); love.graphics.setColor(1,1,1,1) end
  if not core then
    love.graphics.printf(msg or "", 20, H / 2 - 20, W - 40, "center"); return
  end
  local im, w, h, asp = img, 256, 224, 8 / 7
  if sys ~= "nes" then
    im, w, h, asp = core.image, core.w, core.h, core.aspect
    if not im then return end
  end
  local dh = H
  local dw = dh * asp
  if dw > W then dw = W; dh = dw / asp end
  local x, y = (W - dw) / 2, (H - dh) / 2
  if sys == "nes" then
    love.graphics.draw(im, quad, x, y, 0, dw / w, dh / h)
  else
    if core.swap then love.graphics.setShader(core.getShader()) end
    love.graphics.draw(im, x, y, 0, dw / w, dh / h)
    love.graphics.setShader()
  end
end

function love.keypressed(k)
  if k == "escape" then love.event.quit()
  elseif k == "f11" then love.window.setFullscreen(not love.window.getFullscreen()) end
end
function love.filedropped(f) start(f:getFilename(), true) end
function love.focus(f) if not f then saveSram() end end
function love.quit() saveSram() end
