function love.conf(t)
  t.identity = "plnes-emu"
  t.version = "11.5"
  t.externalstorage = false
  t.window.title = "PaloEmu"
  t.window.width = 768
  t.window.height = 720
  t.window.resizable = true
  t.window.fullscreen = true
  t.window.fullscreentype = "desktop"
  t.window.vsync = 1
  t.modules.physics = false
  t.modules.video = false
end
