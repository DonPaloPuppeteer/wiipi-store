-- nes.lua: nucleo NES para LuaJIT/LOVE. CPU 6502, PPU por scanline,
-- mappers 0,1,2,3,4,7. Sin audio (por ahora).
local bit = require("bit")
local ffi = require("ffi")
local band, bor, bxor = bit.band, bit.bor, bit.bxor
local lshift, rshift = bit.lshift, bit.rshift

local NES = { buttons = 0, battery = false }
local curMp

local PALRGB = {
  0x666666,0x002A88,0x1412A7,0x3B00A4,0x5C007E,0x6E0040,0x6C0600,0x561D00,
  0x333500,0x0B4800,0x005200,0x004F08,0x00404D,0x000000,0x000000,0x000000,
  0xADADAD,0x155FD9,0x4240FF,0x7527FE,0xA01ACC,0xB71E7B,0xB53120,0x994E00,
  0x6B6D00,0x388700,0x0C9300,0x008F32,0x007C8D,0x000000,0x000000,0x000000,
  0xFFFEFF,0x64B0FF,0x9290FF,0xC676FF,0xF36AFF,0xFE6ECC,0xFE8170,0xEA9E22,
  0xBCBE00,0x88D800,0x5CE430,0x45E082,0x48CDDE,0x4F4F4F,0x000000,0x000000,
  0xFFFEFF,0xC0DFFF,0xD3D2FF,0xE8C8FF,0xFBC2FF,0xFEC4EA,0xFECCC5,0xF7D8A5,
  0xE4E594,0xCFEF96,0xBDF4AB,0xB3F3CC,0xB5EBF2,0xB8B8B8,0x000000,0x000000,
}
local PAL32 = ffi.new("uint32_t[64]")
for i = 1, 64 do
  local c = PALRGB[i]
  PAL32[i - 1] = rshift(c, 16) + band(rshift(c, 8), 255) * 256 + band(c, 255) * 65536 + 4278190080
end

local CYC = { [0] =
  7,6,0,0,0,3,5,0,3,2,2,0,0,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
  6,6,0,0,3,3,5,0,4,2,2,0,4,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
  6,6,0,0,0,3,5,0,3,2,2,0,3,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
  6,6,0,0,0,3,5,0,4,2,2,0,5,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
  0,6,0,0,3,3,3,0,2,0,2,0,4,4,4,0,  2,6,0,0,4,4,4,0,2,5,2,0,0,5,0,0,
  2,6,2,0,3,3,3,0,2,2,2,0,4,4,4,0,  2,5,0,0,4,4,4,0,2,4,2,0,4,4,4,0,
  2,6,0,0,3,3,5,0,2,2,2,0,4,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
  2,6,0,0,3,3,5,0,2,2,2,0,4,4,6,0,  2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
}

-- memoria
local ram   = ffi.new("uint8_t[2048]")
local sram  = ffi.new("uint8_t[8192]")
local vram  = ffi.new("uint8_t[4096]")
local oam   = ffi.new("uint8_t[256]")
local pal   = ffi.new("uint8_t[32]")
local bgc   = ffi.new("uint8_t[264]")
local lineIdx = ffi.new("uint8_t[264]")
local sprList = ffi.new("int[8]")
local prg, chr, prgSize, chrSize, chrRam
local prgBank, chrBank, ntMap = {}, {}, {}
local pix

-- estado CPU
local a, x, y, sp, pc = 0, 0, 0, 0xFD, 0
local fC, fZ, fI, fD, fV, fN = 0, 0, 1, 0, 0, 0
local nmiPending, irqLine, dmaStall = false, false, 0
-- estado PPU
local ctrl, mask, status, oamAddr = 0, 0, 0, 0
local vreg, treg, fineX, wlatch, readBuf = 0, 0, 0, 0, 0
-- controles
local strobe, shiftReg = 0, 0
-- mapper
local mapperWrite, clockIrq

------------------------------------------------------------ banking
local function setMirror(m)
  if m == "h" then ntMap[0], ntMap[1], ntMap[2], ntMap[3] = 0, 0, 1024, 1024
  elseif m == "v" then ntMap[0], ntMap[1], ntMap[2], ntMap[3] = 0, 1024, 0, 1024
  elseif m == "s0" then ntMap[0], ntMap[1], ntMap[2], ntMap[3] = 0, 0, 0, 0
  elseif m == "s1" then ntMap[0], ntMap[1], ntMap[2], ntMap[3] = 1024, 1024, 1024, 1024
  else ntMap[0], ntMap[1], ntMap[2], ntMap[3] = 0, 1024, 2048, 3072 end
end
local function prg8(slot, b) prgBank[slot] = (b % (prgSize / 8192)) * 8192 end
local function prg16(s2, b)
  b = b % (prgSize / 16384)
  prgBank[s2 * 2], prgBank[s2 * 2 + 1] = b * 16384, b * 16384 + 8192
end
local function prg32(b)
  for i = 0, 3 do prgBank[i] = (b * 32768 + i * 8192) % prgSize end
end
local function chr1(slot, b) chrBank[slot] = (b % (chrSize / 1024)) * 1024 end
local function chr2(s2, b) chr1(s2, band(b, 0xFE)); chr1(s2 + 1, bor(b, 1)) end
local function chr4(s4, b) for i = 0, 3 do chr1(s4 * 4 + i, b * 4 + i) end end
local function chr8(b) for i = 0, 7 do chr1(i, b * 8 + i) end end

local M = {}
M[0] = { init = function()
  for i = 0, 3 do prgBank[i] = (i * 8192) % prgSize end
  chr8(0)
end }
M[2] = { init = function() prg16(0, 0); prg16(1, prgSize / 16384 - 1); chr8(0) end,
  write = function(_, v) prg16(0, v) end }
M[3] = { init = function()
  for i = 0, 3 do prgBank[i] = (i * 8192) % prgSize end
  chr8(0)
end, write = function(_, v) chr8(band(v, 3)) end }
M[7] = { init = function() prg32(0); chr8(0); setMirror("s0") end,
  write = function(_, v) prg32(band(v, 7)); setMirror(band(v, 0x10) ~= 0 and "s1" or "s0") end }


local function simple(init, wr) return { init = init, write = wr } end
local function fixed() for i = 0, 3 do prgBank[i] = (i * 8192) % prgSize end end
M[11] = simple(function() prg32(0); chr8(0) end, function(_, v) prg32(band(v, 3)); chr8(rshift(v, 4)) end)
M[66] = simple(function() prg32(0); chr8(0) end, function(_, v) prg32(band(rshift(v, 4), 3)); chr8(band(v, 3)) end)
M[34] = simple(function() prg32(0); chr8(0) end, function(a, v) if a >= 0x8000 then prg32(v) end end)
M[71] = simple(function() prg16(0, 0); prg16(1, prgSize / 16384 - 1); chr8(0) end, function(a, v) if a >= 0xC000 then prg16(0, v) end end)
M[180] = simple(function() prg16(0, 0); prg16(1, 0); chr8(0) end, function(_, v) prg16(1, v) end)
M[94] = simple(function() prg16(0, 0); prg16(1, prgSize / 16384 - 1); chr8(0) end, function(_, v) prg16(0, rshift(v, 2)) end)
M[152] = simple(function() prg16(0, 0); prg16(1, prgSize / 16384 - 1); chr8(0) end, function(_, v) prg16(0, band(rshift(v, 4), 7)); chr8(band(v, 15)) end)

M[1] = (function()
  local sr, r = 0x10, { [0] = 0x0C, 0, 0, 0 }
  local function upd()
    local c = r[0]
    local mm = band(c, 3)
    setMirror(mm == 0 and "s0" or mm == 1 and "s1" or mm == 2 and "v" or "h")
    local pm, pb = band(rshift(c, 2), 3), band(r[3], 0xF)
    if pm <= 1 then prg32(rshift(pb, 1))
    elseif pm == 2 then prg16(0, 0); prg16(1, pb)
    else prg16(0, pb); prg16(1, prgSize / 16384 - 1) end
    if band(c, 0x10) == 0 then chr8(rshift(r[1], 1)) else chr4(0, r[1]); chr4(1, r[2]) end
  end
  return {
    get = function() return { sr = sr, r0 = r[0], r1 = r[1], r2 = r[2], r3 = r[3] } end,
    set = function(s) sr, r[0], r[1], r[2], r[3] = s.sr, s.r0, s.r1, s.r2, s.r3 end,
    init = function() sr = 0x10; r[0], r[1], r[2], r[3] = 0x0C, 0, 0, 0; upd() end,
    write = function(addr, v)
      if band(v, 0x80) ~= 0 then sr = 0x10; r[0] = bor(r[0], 0x0C); upd(); return end
      local last = band(sr, 1) == 1
      sr = bor(rshift(sr, 1), lshift(band(v, 1), 4))
      if last then r[band(rshift(addr, 13), 3)] = sr; sr = 0x10; upd() end
    end,
  }
end)()

M[4] = (function()
  local sel, r = 0, { [0] = 0, 2, 4, 5, 6, 7, 0, 1 }
  local latch, counter, reload, enable = 0, 0, false, false
  local function upd()
    local n8 = prgSize / 8192
    if band(sel, 0x80) == 0 then
      chr2(0, r[0]); chr2(2, r[1])
      for i = 0, 3 do chr1(4 + i, r[2 + i]) end
    else
      for i = 0, 3 do chr1(i, r[2 + i]) end
      chr2(4, r[0]); chr2(6, r[1])
    end
    if band(sel, 0x40) == 0 then prg8(0, r[6]); prg8(2, n8 - 2)
    else prg8(0, n8 - 2); prg8(2, r[6]) end
    prg8(1, r[7]); prg8(3, n8 - 1)
  end
  return {
    get = function() return { sel = sel, r = { [0] = r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7] }, latch = latch, counter = counter, reload = reload, enable = enable } end,
    set = function(s) sel, latch, counter, reload, enable = s.sel, s.latch, s.counter, s.reload, s.enable; for i = 0, 7 do r[i] = s.r[i] end end,
    init = function()
      sel, latch, counter, reload, enable = 0, 0, 0, false, false
      r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7] = 0, 2, 4, 5, 6, 7, 0, 1
      setMirror("v"); upd()
    end,
    write = function(addr, v)
      local k = band(addr, 0xE001)
      if k == 0x8000 then sel = v; upd()
      elseif k == 0x8001 then r[band(sel, 7)] = v; upd()
      elseif k == 0xA000 then setMirror(band(v, 1) == 1 and "h" or "v")
      elseif k == 0xC000 then latch = v
      elseif k == 0xC001 then counter = 0; reload = true
      elseif k == 0xE000 then enable = false; irqLine = false
      elseif k == 0xE001 then enable = true end
    end,
    clock = function()
      if counter == 0 or reload then counter = latch; reload = false
      else counter = counter - 1 end
      if counter == 0 and enable then irqLine = true end
    end,
  }
end)()

------------------------------------------------------------ PPU
local function ppuRead(ad)
  ad = band(ad, 0x3FFF)
  if ad < 0x2000 then return chr[chrBank[rshift(ad, 10)] + band(ad, 0x3FF)]
  elseif ad < 0x3F00 then return vram[ntMap[band(rshift(ad, 10), 3)] + band(ad, 0x3FF)] end
  ad = band(ad, 0x1F)
  if ad >= 16 and band(ad, 3) == 0 then ad = ad - 16 end
  return pal[ad]
end
local function ppuWrite(ad, v)
  ad = band(ad, 0x3FFF)
  if ad < 0x2000 then
    if chrRam then chr[chrBank[rshift(ad, 10)] + band(ad, 0x3FF)] = v end
  elseif ad < 0x3F00 then vram[ntMap[band(rshift(ad, 10), 3)] + band(ad, 0x3FF)] = v
  else
    ad = band(ad, 0x1F)
    if ad >= 16 and band(ad, 3) == 0 then ad = ad - 16 end
    pal[ad] = band(v, 0x3F)
  end
end

local function ppuRegRead(rg)
  if rg == 2 then
    local s = status
    status = band(status, 0x7F); wlatch = 0
    return s
  elseif rg == 4 then return oam[oamAddr]
  elseif rg == 7 then
    local ad, res = band(vreg, 0x3FFF), 0
    if ad >= 0x3F00 then res = ppuRead(ad); readBuf = ppuRead(ad - 0x1000)
    else res = readBuf; readBuf = ppuRead(ad) end
    vreg = band(vreg + (band(ctrl, 4) ~= 0 and 32 or 1), 0x7FFF)
    return res
  end
  return 0
end

local function ppuRegWrite(rg, v)
  if rg == 0 then
    local was = band(ctrl, 0x80) ~= 0
    ctrl = v
    treg = bor(band(treg, 0xF3FF), lshift(band(v, 3), 10))
    if not was and band(v, 0x80) ~= 0 and band(status, 0x80) ~= 0 then nmiPending = true end
  elseif rg == 1 then mask = v
  elseif rg == 3 then oamAddr = v
  elseif rg == 4 then oam[oamAddr] = v; oamAddr = band(oamAddr + 1, 255)
  elseif rg == 5 then
    if wlatch == 0 then
      treg = bor(band(treg, 0xFFE0), rshift(v, 3)); fineX = band(v, 7); wlatch = 1
    else
      treg = bor(band(treg, 0x0C1F), lshift(band(v, 7), 12), lshift(band(v, 0xF8), 2)); wlatch = 0
    end
  elseif rg == 6 then
    if wlatch == 0 then treg = bor(band(treg, 0x00FF), lshift(band(v, 0x3F), 8)); wlatch = 1
    else treg = bor(band(treg, 0x7F00), v); vreg = treg; wlatch = 0 end
  elseif rg == 7 then
    ppuWrite(vreg, v)
    vreg = band(vreg + (band(ctrl, 4) ~= 0 and 32 or 1), 0x7FFF)
  end
end

local function renderLine(yy, skip)
  local base = yy * 256
  local m = mask
  if band(m, 0x18) == 0 then
    local c = PAL32[band(pal[0], 0x3F)]
    if not skip then for xx = 0, 255 do pix[base + xx] = c end end
    return
  end
  local v = vreg
  if not skip or (band(status, 0x40) == 0 and yy > oam[0] and yy <= oam[0] + 16) then
  if band(m, 8) ~= 0 then
    local fy = band(rshift(v, 12), 7)
    local cx, cy, nt = band(v, 31), band(rshift(v, 5), 31), band(rshift(v, 10), 3)
    local pbase = band(ctrl, 0x10) ~= 0 and 0x1000 or 0
    local left = band(m, 2) ~= 0
    local sx = -fineX
    for _ = 0, 32 do
      local nb = ntMap[nt]
      local ti = vram[nb + cy * 32 + cx]
      local at = vram[nb + 0x3C0 + rshift(cy, 2) * 8 + rshift(cx, 2)]
      local p4 = band(rshift(at, band(cy, 2) * 2 + band(cx, 2)), 3) * 4
      local a0 = pbase + ti * 16 + fy
      local lo = chr[chrBank[rshift(a0, 10)] + band(a0, 0x3FF)]
      local a1 = a0 + 8
      local hi = chr[chrBank[rshift(a1, 10)] + band(a1, 0x3FF)]
      for px = 0, 7 do
        local xx = sx + px
        if xx >= 0 and xx < 256 then
          local b = 7 - px
          local c = bor(band(rshift(lo, b), 1), lshift(band(rshift(hi, b), 1), 1))
          if c ~= 0 and (xx >= 8 or left) then bgc[xx] = c; lineIdx[xx] = pal[p4 + c]
          else bgc[xx] = 0; lineIdx[xx] = pal[0] end
        end
      end
      sx = sx + 8
      cx = cx + 1
      if cx == 32 then cx = 0; nt = bxor(nt, 1) end
    end
  else
    for xx = 0, 255 do bgc[xx] = 0; lineIdx[xx] = pal[0] end
  end

  if band(m, 0x10) ~= 0 then
    local h = band(ctrl, 0x20) ~= 0 and 16 or 8
    local cnt = 0
    for i = 0, 63 do
      local row = yy - oam[i * 4] - 1
      if row >= 0 and row < h then
        if cnt < 8 then sprList[cnt] = i; cnt = cnt + 1
        else status = bor(status, 0x20); break end
      end
    end
    local sleft = band(m, 4) ~= 0
    for k = cnt - 1, 0, -1 do
      local i = sprList[k]
      local tile, at, sxp = oam[i * 4 + 1], oam[i * 4 + 2], oam[i * 4 + 3]
      local row = yy - oam[i * 4] - 1
      if band(at, 0x80) ~= 0 then row = h - 1 - row end
      local a0
      if h == 8 then a0 = (band(ctrl, 8) ~= 0 and 0x1000 or 0) + tile * 16 + row
      else
        local tb = band(tile, 1) * 0x1000
        tile = band(tile, 0xFE)
        if row >= 8 then tile = tile + 1; row = row - 8 end
        a0 = tb + tile * 16 + row
      end
      local lo = chr[chrBank[rshift(a0, 10)] + band(a0, 0x3FF)]
      local a1 = a0 + 8
      local hi = chr[chrBank[rshift(a1, 10)] + band(a1, 0x3FF)]
      local fh = band(at, 0x40) ~= 0
      local behind = band(at, 0x20) ~= 0
      local p4 = 16 + band(at, 3) * 4
      for px = 0, 7 do
        local xx = sxp + px
        if xx < 256 and (xx >= 8 or sleft) then
          local b = fh and px or 7 - px
          local c = bor(band(rshift(lo, b), 1), lshift(band(rshift(hi, b), 1), 1))
          if c ~= 0 then
            if i == 0 and bgc[xx] ~= 0 and xx ~= 255 and band(m, 8) ~= 0 then
              status = bor(status, 0x40)
            end
            if not (behind and bgc[xx] ~= 0) then lineIdx[xx] = pal[p4 + c] end
          end
        end
      end
    end
  end

  for xx = 0, 255 do pix[base + xx] = PAL32[band(lineIdx[xx], 0x3F)] end

  end
  -- avanzar scroll: Y y copiar X desde t
  if band(v, 0x7000) ~= 0x7000 then v = v + 0x1000
  else
    v = band(v, 0x0FFF)
    local cy = band(rshift(v, 5), 31)
    if cy == 29 then cy = 0; v = bxor(v, 0x0800)
    elseif cy == 31 then cy = 0
    else cy = cy + 1 end
    v = bor(band(v, 0x7C1F), lshift(cy, 5))
  end
  vreg = bor(band(v, 0x7BE0), band(treg, 0x041F))
  if clockIrq then clockIrq() end
end

------------------------------------------------------------ APU
local LEN = { [0] = 10,254,20,2,40,4,80,6,160,8,60,10,14,12,26,14,12,16,24,18,48,20,96,22,192,24,72,26,16,28,32,30 }
local NP = { [0] = 4,8,16,32,64,96,128,160,202,254,380,508,762,1016,2034,4068 }
local DUTY = { [0] = 0x40, 0x60, 0x78, 0x9F }
local P1, P2, TR, NZ, CH
local abuf, ai = nil, 0
local fcyc, fstep = 0, 0
local function ch()
  return { len = 0, en = false, t = 0, pos = 0, halt = false, const = false, vol = 0, dec = 0, div = 0,
    start = false, duty = 0, sen = false, sper = 0, sneg = false, ssh = 0, srel = false, sdiv = 0,
    lin = 0, linr = 0, linf = false, mode = false, acc = 0, sr = 1, per = 4 }
end
local function resetApu()
  P1, P2, TR, NZ = ch(), ch(), ch(), ch()
  P1.ones = true
  CH = { P1, P2, TR, NZ }
  fcyc, fstep = 0, 0
end
local function apuStatus()
  return (P1.len > 0 and 1 or 0) + (P2.len > 0 and 2 or 0) + (TR.len > 0 and 4 or 0) + (NZ.len > 0 and 8 or 0)
end
local function apuWrite(ad, v)
  if ad == 0x4015 then
    for i = 1, 4 do
      CH[i].en = band(v, lshift(1, i - 1)) ~= 0
      if not CH[i].en then CH[i].len = 0 end
    end
    return
  end
  local c = ad < 0x4004 and P1 or ad < 0x4008 and P2 or ad < 0x400C and TR or NZ
  local r = band(ad, 3)
  if c == TR then
    if r == 0 then c.halt = band(v, 0x80) ~= 0; c.linr = band(v, 0x7F)
    elseif r == 2 then c.t = bor(band(c.t, 0x700), v)
    elseif r == 3 then
      c.t = bor(band(c.t, 0xFF), lshift(band(v, 7), 8))
      if c.en then c.len = LEN[rshift(v, 3)] end
      c.linf = true
    end
  elseif c == NZ then
    if r == 0 then c.halt = band(v, 0x20) ~= 0; c.const = band(v, 0x10) ~= 0; c.vol = band(v, 15)
    elseif r == 2 then c.mode = band(v, 0x80) ~= 0; c.per = NP[band(v, 15)]
    elseif r == 3 then
      if c.en then c.len = LEN[rshift(v, 3)] end
      c.start = true
    end
  else
    if r == 0 then
      c.duty = rshift(v, 6); c.halt = band(v, 0x20) ~= 0; c.const = band(v, 0x10) ~= 0; c.vol = band(v, 15)
    elseif r == 1 then
      c.sen = band(v, 0x80) ~= 0; c.sper = band(rshift(v, 4), 7); c.sneg = band(v, 8) ~= 0
      c.ssh = band(v, 7); c.srel = true
    elseif r == 2 then c.t = bor(band(c.t, 0x700), v)
    else
      c.t = bor(band(c.t, 0xFF), lshift(band(v, 7), 8))
      if c.en then c.len = LEN[rshift(v, 3)] end
      c.pos = 0; c.start = true
    end
  end
end
local function env(c)
  if c.start then c.start = false; c.dec = 15; c.div = c.vol
  elseif c.div == 0 then
    c.div = c.vol
    if c.dec > 0 then c.dec = c.dec - 1 elseif c.halt then c.dec = 15 end
  else c.div = c.div - 1 end
end
local function sweep(c)
  local d = rshift(c.t, c.ssh)
  local tg = c.sneg and (c.t - d - (c.ones and 1 or 0)) or (c.t + d)
  if c.sdiv == 0 and c.sen and c.ssh > 0 and c.t >= 8 and tg <= 0x7FF and tg >= 0 then c.t = tg end
  if c.sdiv == 0 or c.srel then c.sdiv = c.sper; c.srel = false else c.sdiv = c.sdiv - 1 end
end
local function sample()
  fcyc = fcyc + 40.58
  if fcyc >= 7457.5 then
    fcyc = fcyc - 7457.5
    fstep = (fstep + 1) % 4
    env(P1); env(P2); env(NZ)
    if TR.linf then TR.lin = TR.linr elseif TR.lin > 0 then TR.lin = TR.lin - 1 end
    if not TR.halt then TR.linf = false end
    if fstep == 1 or fstep == 3 then
      for i = 1, 4 do local c = CH[i]; if not c.halt and c.len > 0 then c.len = c.len - 1 end end
      sweep(P1); sweep(P2)
    end
  end
  local pul = 0
  for i = 1, 2 do
    local c = CH[i]
    if c.len > 0 and c.t >= 8 and (c.sneg or c.t + rshift(c.t, c.ssh) <= 0x7FF) then
      c.pos = (c.pos + 20.29 / (c.t + 1)) % 8
      if band(rshift(DUTY[c.duty], 7 - math.floor(c.pos)), 1) == 1 then pul = pul + (c.const and c.vol or c.dec) end
    end
  end
  local tri = 0
  if TR.len > 0 and TR.lin > 0 and TR.t >= 2 then
    TR.pos = (TR.pos + 40.58 / (TR.t + 1)) % 32
    local s = math.floor(TR.pos)
    tri = s < 16 and 15 - s or s - 16
  end
  local noi = 0
  if NZ.len > 0 then
    local vol = NZ.const and NZ.vol or NZ.dec
    NZ.acc = NZ.acc + 40.58
    local steps, sum = 0, 0
    while NZ.acc >= NZ.per do
      NZ.acc = NZ.acc - NZ.per
      local sr = NZ.sr
      NZ.sr = bor(rshift(sr, 1), lshift(bxor(band(sr, 1), band(rshift(sr, NZ.mode and 6 or 1), 1)), 14))
      steps = steps + 1
      if band(NZ.sr, 1) == 0 then sum = sum + vol end
    end
    local cur = band(NZ.sr, 1) == 0 and vol or 0
    noi = steps > 0 and sum / steps or cur   -- promedio (anti-aliasing): ya no chilla
    NZ.lp = (NZ.lp or 0) + (noi - (NZ.lp or 0)) * 0.55
    noi = NZ.lp
  else NZ.lp = 0 end
  return (0.00752 * pul + 0.00851 * tri + 0.00494 * noi * 0.45) * 2.2
end
------------------------------------------------------------ bus CPU
local function rd(ad)
  if ad < 0x2000 then return ram[band(ad, 0x7FF)]
  elseif ad >= 0x8000 then return prg[prgBank[rshift(ad, 13) - 4] + band(ad, 0x1FFF)]
  elseif ad < 0x4000 then return ppuRegRead(band(ad, 7))
  elseif ad == 0x4016 then
    if strobe == 1 then return band(NES.buttons, 1) end
    local r = band(shiftReg, 1)
    shiftReg = bor(rshift(shiftReg, 1), 0x80)
    return bor(r, 0x40)
  elseif ad == 0x4015 then return apuStatus()
  elseif ad >= 0x6000 then return sram[ad - 0x6000] end
  return 0
end

local function wr(ad, v)
  if ad < 0x2000 then ram[band(ad, 0x7FF)] = v
  elseif ad >= 0x8000 then if mapperWrite then mapperWrite(ad, v) end
  elseif ad < 0x4000 then ppuRegWrite(band(ad, 7), v)
  elseif (ad >= 0x4000 and ad <= 0x4013) or ad == 0x4015 then apuWrite(ad, v)
  elseif ad == 0x4014 then
    local b = lshift(v, 8)
    for i = 0, 255 do oam[band(oamAddr + i, 255)] = rd(b + i) end
    dmaStall = 513
  elseif ad == 0x4016 then
    strobe = band(v, 1)
    if strobe == 1 then shiftReg = NES.buttons end
  elseif ad >= 0x6000 then sram[ad - 0x6000] = v end
end

------------------------------------------------------------ CPU
local function fetch() local v = rd(pc); pc = band(pc + 1, 0xFFFF); return v end
local function fetch16() local lo = fetch(); return lo + lshift(fetch(), 8) end
local function push(v) wr(0x100 + sp, v); sp = band(sp - 1, 255) end
local function pull() sp = band(sp + 1, 255); return rd(0x100 + sp) end
local function nz(v) fZ = (v == 0) and 1 or 0; fN = rshift(v, 7) end
local function getP(brk)
  return fC + fZ * 2 + fI * 4 + fD * 8 + (brk and 0x30 or 0x20) + fV * 64 + fN * 128
end
local function setP(v)
  fC, fZ = band(v, 1), band(rshift(v, 1), 1)
  fI, fD = band(rshift(v, 2), 1), band(rshift(v, 3), 1)
  fV, fN = band(rshift(v, 6), 1), rshift(v, 7)
end
local function adc(v)
  local s = a + v + fC
  fV = band(rshift(band(bxor(a, s), bxor(v, s)), 7), 1)
  fC = s > 255 and 1 or 0
  a = band(s, 255); nz(a)
end
local function cmp(r, v)
  fC = r >= v and 1 or 0
  nz(band(r - v, 255))
end
local function rmw(k, v)
  local r
  if k == 0 then fC = rshift(v, 7); r = band(lshift(v, 1), 255)
  elseif k == 1 then local c = fC; fC = rshift(v, 7); r = bor(band(lshift(v, 1), 255), c)
  elseif k == 2 then fC = band(v, 1); r = rshift(v, 1)
  elseif k == 3 then local c = fC; fC = band(v, 1); r = bor(rshift(v, 1), lshift(c, 7))
  elseif k == 6 then r = band(v - 1, 255)
  else r = band(v + 1, 255) end
  nz(r); return r
end
local function ea(m, i)
  if m == 1 then return fetch()
  elseif m == 3 then return fetch16()
  elseif m == 5 then return band(fetch() + i, 0xFF)
  elseif m == 7 then return band(fetch16() + i, 0xFFFF)
  elseif m == 6 then return band(fetch16() + y, 0xFFFF)
  elseif m == 0 then
    local z = band(fetch() + x, 0xFF)
    return rd(z) + lshift(rd(band(z + 1, 0xFF)), 8)
  else
    local z = fetch()
    return band(rd(z) + lshift(rd(band(z + 1, 0xFF)), 8) + y, 0xFFFF)
  end
end
local function interrupt(vec, brk)
  push(rshift(pc, 8)); push(band(pc, 255))
  push(getP(brk)); fI = 1
  pc = rd(vec) + lshift(rd(vec + 1), 8)
  return 7
end

local function step()
  if nmiPending then nmiPending = false; return interrupt(0xFFFA) end
  if irqLine and fI == 0 then return interrupt(0xFFFE) end
  local op = fetch()
  local cyc = CYC[op]
  if cyc == 0 then cyc = 2 end
  local cc = band(op, 3)
  local aaa, bbb = rshift(op, 5), band(rshift(op, 2), 7)

  if band(op, 0x1F) == 0x10 then -- ramas
    local k, f = rshift(op, 6), 0
    if k == 0 then f = fN elseif k == 1 then f = fV elseif k == 2 then f = fC else f = fZ end
    local off = fetch()
    if f == (band(op, 0x20) ~= 0 and 1 or 0) then
      if off >= 128 then off = off - 256 end
      local np = band(pc + off, 0xFFFF)
      cyc = cyc + 1
      if band(np, 0xFF00) ~= band(pc, 0xFF00) then cyc = cyc + 1 end
      pc = np
    end
  elseif cc == 1 then
    if aaa == 4 then
      if bbb == 2 then fetch() else wr(ea(bbb, x), a) end
    else
      local v
      if bbb == 2 then v = fetch() else v = rd(ea(bbb, x)) end
      if aaa == 0 then a = bor(a, v); nz(a)
      elseif aaa == 1 then a = band(a, v); nz(a)
      elseif aaa == 2 then a = bxor(a, v); nz(a)
      elseif aaa == 3 then adc(v)
      elseif aaa == 5 then a = v; nz(a)
      elseif aaa == 6 then cmp(a, v)
      else adc(bxor(v, 255)) end
    end
  elseif cc == 2 then
    if bbb == 6 then
      if aaa == 4 then sp = x elseif aaa == 5 then x = sp; nz(x) end
    elseif bbb == 2 and aaa >= 4 then
      if aaa == 4 then a = x; nz(a)
      elseif aaa == 5 then x = a; nz(x)
      elseif aaa == 6 then x = band(x - 1, 255); nz(x) end
    elseif aaa == 4 then
      if bbb == 0 then fetch() elseif bbb ~= 4 then wr(ea(bbb, y), x) end
    elseif aaa == 5 then
      if bbb == 0 then x = fetch() elseif bbb ~= 4 then x = rd(ea(bbb, y)) end
      nz(x)
    elseif bbb == 2 then a = rmw(aaa, a)
    elseif bbb == 0 then
      if aaa >= 6 then fetch() end
    elseif bbb ~= 0 and bbb ~= 4 then
      local ad = ea(bbb, x)
      wr(ad, rmw(aaa, rd(ad)))
    end
  elseif cc == 0 then
    if bbb == 0 and aaa <= 3 then
      if aaa == 0 then pc = band(pc + 1, 0xFFFF); cyc = cyc + interrupt(0xFFFE, true) - 7
      elseif aaa == 1 then
        local ad = fetch16(); local r = band(pc - 1, 0xFFFF)
        push(rshift(r, 8)); push(band(r, 255)); pc = ad
      elseif aaa == 2 then
        setP(pull()); local lo = pull(); pc = lo + lshift(pull(), 8)
      else
        local lo = pull(); pc = band(lo + lshift(pull(), 8) + 1, 0xFFFF)
      end
    elseif bbb == 2 then
      if aaa == 0 then push(getP(true))
      elseif aaa == 1 then setP(pull())
      elseif aaa == 2 then push(a)
      elseif aaa == 3 then a = pull(); nz(a)
      elseif aaa == 4 then y = band(y - 1, 255); nz(y)
      elseif aaa == 5 then y = a; nz(y)
      elseif aaa == 6 then y = band(y + 1, 255); nz(y)
      else x = band(x + 1, 255); nz(x) end
    elseif bbb == 6 then
      if aaa == 0 then fC = 0 elseif aaa == 1 then fC = 1
      elseif aaa == 2 then fI = 0 elseif aaa == 3 then fI = 1
      elseif aaa == 4 then a = y; nz(a)
      elseif aaa == 5 then fV = 0
      elseif aaa == 6 then fD = 0 else fD = 1 end
    elseif bbb == 3 and aaa == 2 then pc = fetch16()
    elseif bbb == 3 and aaa == 3 then
      local p = fetch16()
      local lo = rd(p)
      pc = lo + lshift(rd(bor(band(p, 0xFF00), band(p + 1, 0xFF))), 8)
    elseif bbb ~= 4 then
      if aaa == 4 and bbb ~= 0 and bbb ~= 7 then wr(ea(bbb, x), y)
      elseif (aaa == 1 and (bbb == 1 or bbb == 3)) or aaa == 5 or (aaa >= 6 and bbb <= 3) then
        local v
        if bbb == 0 then v = fetch() else v = rd(ea(bbb, x)) end
        if aaa == 1 then fZ = band(a, v) == 0 and 1 or 0; fN = rshift(v, 7); fV = band(rshift(v, 6), 1)
        elseif aaa == 5 then y = v; nz(y)
        elseif aaa == 6 then cmp(y, v)
        else cmp(x, v) end
      elseif bbb == 0 then fetch()
      else ea(bbb, x) end
    end
  end

  local c = cyc + dmaStall
  dmaStall = 0
  return c
end

------------------------------------------------------------ API
function NES.setBuffer(ptr) pix = ptr end

function NES.load(data)
  if data:sub(1, 4) ~= "NES\26" then return nil, "No es un archivo .nes valido" end
  local pn, cn, f6, f7 = data:byte(5, 8)
  local id = bor(rshift(f6, 4), band(f7, 0xF0))
  local mp = M[id]
  if not mp then return nil, "Mapper " .. id .. " no soportado todavia" end
  local off = 16 + (band(f6, 4) ~= 0 and 512 or 0)
  prgSize = pn * 16384
  prg = ffi.new("uint8_t[?]", prgSize)
  local s = data:sub(off + 1, off + prgSize)
  ffi.copy(prg, s, #s)
  off = off + prgSize
  chrRam = (cn == 0)
  chrSize = chrRam and 8192 or cn * 8192
  chr = ffi.new("uint8_t[?]", chrSize)
  if not chrRam then
    s = data:sub(off + 1, off + chrSize)
    ffi.copy(chr, s, #s)
  end
  NES.battery = band(f6, 2) ~= 0
  ffi.fill(ram, 2048); ffi.fill(sram, 8192); ffi.fill(vram, 4096)
  ffi.fill(oam, 256); ffi.fill(pal, 32)
  setMirror(band(f6, 8) ~= 0 and "4" or (band(f6, 1) == 1 and "v" or "h"))
  mp.init()
  curMp = mp
  mapperWrite, clockIrq = mp.write, mp.clock
  irqLine, nmiPending, dmaStall = false, false, 0
  ctrl, mask, status, oamAddr, vreg, treg, fineX, wlatch, readBuf = 0, 0, 0, 0, 0, 0, 0, 0, 0
  strobe, shiftReg = 0, 0
  a, x, y, sp = 0, 0, 0, 0xFD
  fC, fZ, fI, fD, fV, fN = 0, 0, 1, 0, 0, 0
  resetApu()
  pc = rd(0xFFFC) + lshift(rd(0xFFFD), 8)
  return true
end

function NES.getSram() return ffi.string(sram, 8192) end
function NES.setSram(str) ffi.copy(sram, str, math.min(#str, 8192)) end

local budget = 0
function NES.setAudio(ptr) abuf = ptr end
function NES.frame(skip)
  ai = 0
  for sl = 0, 261 do
    if sl < 240 then renderLine(sl, skip)
    elseif sl == 241 then
      status = bor(status, 0x80)
      if band(ctrl, 0x80) ~= 0 then nmiPending = true end
    elseif sl == 261 then
      status = band(status, 0x1F)
      if band(mask, 0x18) ~= 0 then
        vreg = bor(band(vreg, 0x041F), band(treg, 0x7BE0))
        if clockIrq then clockIrq() end
      end
    end
    budget = budget + 113.6667
    while budget > 0 do budget = budget - step() end
    if abuf then
      for _ = 1, math.floor((sl + 1) * 735 / 262) - math.floor(sl * 735 / 262) do
        abuf[ai] = sample() * 32000
        ai = ai + 1
      end
    end
  end
end

local function ser(v)
  local t = type(v)
  if t == "table" then
    local o = {}
    for k, x in pairs(v) do o[#o + 1] = "[" .. ser(k) .. "]=" .. ser(x) end
    return "{" .. table.concat(o, ",") .. "}"
  elseif t == "string" then return string.format("%q", v)
  elseif t == "number" then return string.format("%.17g", v)
  else return tostring(v) end
end
local function cp(dst, src) for k, v in pairs(src) do dst[k] = v end end
function NES.getState()
  local s = {
    ram = ffi.string(ram, 2048), sram = ffi.string(sram, 8192), vram = ffi.string(vram, 4096),
    oam = ffi.string(oam, 256), pal = ffi.string(pal, 32), chr = chrRam and ffi.string(chr, chrSize) or false,
    prgBank = prgBank, chrBank = chrBank, ntMap = ntMap,
    cpu = { a, x, y, sp, pc, fC, fZ, fI, fD, fV, fN, nmiPending, irqLine, dmaStall },
    ppu = { ctrl, mask, status, oamAddr, vreg, treg, fineX, wlatch, readBuf },
    io = { strobe, shiftReg, budget }, apu = { P1, P2, TR, NZ, fcyc, fstep },
    mp = curMp and curMp.get and curMp.get() or false,
  }
  return ser(s)
end
function NES.setState(str)
  local f = loadstring("return " .. str)
  if not f then return false end
  local ok, s = pcall(f)
  if not ok or type(s) ~= "table" or not s.ram then return false end
  ffi.copy(ram, s.ram, 2048); ffi.copy(sram, s.sram, 8192); ffi.copy(vram, s.vram, 4096)
  ffi.copy(oam, s.oam, 256); ffi.copy(pal, s.pal, 32)
  if s.chr and chrRam then ffi.copy(chr, s.chr, math.min(#s.chr, chrSize)) end
  cp(prgBank, s.prgBank); cp(chrBank, s.chrBank); cp(ntMap, s.ntMap)
  local c = s.cpu
  a, x, y, sp, pc, fC, fZ, fI, fD, fV, fN, nmiPending, irqLine, dmaStall = c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8], c[9], c[10], c[11], c[12], c[13], c[14]
  c = s.ppu
  ctrl, mask, status, oamAddr, vreg, treg, fineX, wlatch, readBuf = c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8], c[9]
  strobe, shiftReg, budget = s.io[1], s.io[2], s.io[3]
  P1, P2, TR, NZ, fcyc, fstep = s.apu[1], s.apu[2], s.apu[3], s.apu[4], s.apu[5], s.apu[6]
  CH = { P1, P2, TR, NZ }
  if s.mp and curMp and curMp.set then curMp.set(s.mp) end
  return true
end

return NES
