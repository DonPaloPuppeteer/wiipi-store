-- retro.lua: puente LuaJIT-FFI generico a cores libretro (snes9x, mgba...). Los .so van en la raiz.
local ffi = require("ffi")
local bit = require("bit")
local band, bor, lshift, rshift = bit.band, bit.bor, bit.lshift, bit.rshift
ffi.cdef[[
typedef struct { const char *path; const void *data; size_t size; const char *meta; } retro_game_info;
typedef struct { const char *key; const char *value; } retro_variable;
typedef struct { unsigned base_width, base_height, max_width, max_height; float aspect_ratio; } retro_game_geometry;
typedef struct { double fps, sample_rate; } retro_system_timing;
typedef struct { retro_game_geometry geometry; retro_system_timing timing; } retro_system_av_info;
typedef void (*retro_log_t)(int, const char*);
typedef bool (*retro_environment_t)(unsigned, void*);
typedef void (*retro_video_refresh_t)(const void*, unsigned, unsigned, size_t);
typedef void (*retro_audio_sample_t)(int16_t, int16_t);
typedef size_t (*retro_audio_sample_batch_t)(const int16_t*, size_t);
typedef void (*retro_input_poll_t)(void);
typedef int16_t (*retro_input_state_t)(unsigned, unsigned, unsigned, unsigned);
void retro_set_environment(retro_environment_t);
void retro_set_video_refresh(retro_video_refresh_t);
void retro_set_audio_sample(retro_audio_sample_t);
void retro_set_audio_sample_batch(retro_audio_sample_batch_t);
void retro_set_input_poll(retro_input_poll_t);
void retro_set_input_state(retro_input_state_t);
void retro_init(void);
void retro_get_system_av_info(retro_system_av_info*);
void retro_set_controller_port_device(unsigned, unsigned);
void retro_run(void);
size_t retro_serialize_size(void);
bool retro_serialize(void*, size_t);
bool retro_unserialize(const void*, size_t);
bool retro_load_game(const retro_game_info*);
void retro_unload_game(void);
void *retro_get_memory_data(unsigned);
size_t retro_get_memory_size(unsigned);
]]
pcall(ffi.cdef, "int chmod(const char *, unsigned int);")

return function(cfg)
local S = { defaults = {}, aq = 0, fr = 0, cfg_vars = cfg.vars, image = nil, w = 0, h = 0, aspect = cfg.aspect, fps = cfg.fps, loaded = false }
local core, pixfmt, lut = nil, 1, nil
local imgdata, dst, mask, skipV = nil, nil, 0, false
local CAP = 32768
local audioBuf = ffi.new("int16_t[?]", CAP * 2)
local audioN, src, srate, sdc, sdp = 0, nil, 32040, {}, {}
local sysdirC
local vstr, ax, shader = {}, { 0, 0, 0, 0 }, nil

local function buildLut()
  lut = ffi.new("uint32_t[65536]")
  for p = 0, 65535 do
    local r5, g6, b5 = rshift(p, 11), band(rshift(p, 5), 63), band(p, 31)
    local r = bor(lshift(r5, 3), rshift(r5, 2))
    local g = bor(lshift(g6, 2), rshift(g6, 4))
    local b = bor(lshift(b5, 3), rshift(b5, 2))
    lut[p] = r + g * 256 + b * 65536 + 4278190080
  end
end

local logN = 0
local function LOG(s)
  if logN < 200 then logN = logN + 1; pcall(love.filesystem.append, "retro_log.txt", s .. "\n") end
end
local function onLog(lv, fmt) pcall(function() LOG("[core" .. lv .. "] " .. ffi.string(fmt):gsub("%s+$", "")) end) end
local function onEnv0(cmd, data)
  cmd = band(cmd, 0xFFFF)
  if cmd == 27 then ffi.cast("void**", data)[0] = ffi.cast("void*", S.logcb); return true end
  if cmd == 10 then
    local f = ffi.cast("int*", data)[0]
    if f == 1 or f == 2 then pixfmt = f; return true end
    return false
  elseif cmd == 3 or cmd == 51 then
    if cmd == 3 then ffi.cast("bool*", data)[0] = true end
    return true
  elseif cmd == 9 or cmd == 31 then ffi.cast("const char**", data)[0] = sysdirC; return true
  elseif cmd == 15 then
    local v = ffi.cast("retro_variable*", data)
    local key = ffi.string(v.key)
    local val = (cfg.vars and cfg.vars[key]) or S.defaults[key]
    if val then
      vstr[val] = vstr[val] or ffi.new("char[?]", #val + 1, val)
      v.value = vstr[val]; return true
    end
    return false
  elseif cmd == 17 then ffi.cast("bool*", data)[0] = false; return true
  elseif cmd == 37 then
    local g = ffi.cast("retro_game_geometry*", data)
    if g.aspect_ratio > 0 then S.aspect = g.aspect_ratio end
    return true
  elseif cmd == 16 then
    local v = ffi.cast("retro_variable*", data)
    local i = 0
    while v[i].key ~= nil do
      local d = v[i].value ~= nil and ffi.string(v[i].value):match(";%s*([^|]*)")
      if d then S.defaults[ffi.string(v[i].key)] = d end
      i = i + 1
    end
    return true
  elseif cmd == 8 or cmd == 11 or cmd == 32 or cmd == 35 or cmd == 36 then
    return true
  end
  return false
end

local function onVideo0(data, w, h, pitch)
  if data == nil or skipV or tonumber(ffi.cast("intptr_t", data)) == -1 then return end
  if w < 1 or h < 1 or w > 1280 or h > 960 or tonumber(pitch) < w * (pixfmt == 2 and 2 or 4) then return end
  if w ~= S.w or h ~= S.h then
    S.w, S.h = w, h
    imgdata = love.image.newImageData(w, h)
    dst = ffi.cast("uint32_t*", imgdata:getFFIPointer())
    S.image = love.graphics.newImage(imgdata)
    S.image:setFilter("linear", "linear")
  end
  if pixfmt == 2 then
    S.swap = false
    if not lut then buildLut() end
    local s, st = ffi.cast("const uint16_t*", data), tonumber(pitch) / 2
    for y = 0, h - 1 do
      local r, o = y * st, y * w
      for x = 0, w - 1 do dst[o + x] = lut[s[r + x]] end
    end
  else
    S.swap = true   -- BGRX -> RGBA se corrige en shader (copia directa, sin bucle por pixel)
    local sp, row = tonumber(pitch), w * 4
    if sp == row then ffi.copy(dst, data, row * h)
    else
      local s8 = ffi.cast("const uint8_t*", data)
      for y = 0, h - 1 do ffi.copy(dst + y * w, s8 + y * sp, row) end
    end
  end
  S.image:replacePixels(imgdata)
end

local function onAudio1(l, r)
  if not src then return end
  if audioN < CAP then audioBuf[audioN * 2] = l; audioBuf[audioN * 2 + 1] = r; audioN = audioN + 1 end
end
local function onAudioBatch(data, frames)
  frames = tonumber(frames)
  if src and audioN + frames <= CAP then
    ffi.copy(audioBuf + audioN * 2, data, frames * 4)
    audioN = audioN + frames
  end
  return frames
end
local function onEnv(c, d) local ok, r = pcall(onEnv0, c, d); return ok and r or false end
local function onVideo(...) pcall(onVideo0, ...) end
local function onPoll() end
local seenIn, nIn = {}, 0
local function onInput(port, device, index, id)
  if nIn < 12 then local k = port .. ":" .. device .. ":" .. index .. ":" .. id; if not seenIn[k] then seenIn[k] = 1; nIn = nIn + 1; LOG("in " .. k) end end
  if port ~= 0 then return 0 end
  device = band(device, 0xFF)
  if device == 5 then if S.aq < 3 then LOG("analog " .. index .. ":" .. id) end; S.aq = S.aq + 1 end
  if device == 5 then
    if id ~= 0 and id ~= 1 then return 0 end
    if index == 0 then return id == 0 and ax[1] or ax[2] end
    if index == 1 then return id == 0 and ax[3] or ax[4] end
    return 0
  end
  if device ~= 1 then return 0 end
  if id == 256 then return mask end
  return band(rshift(mask, id), 1)
end

S.logcb = ffi.cast("retro_log_t", onLog)
local cbs = {
  env = ffi.cast("retro_environment_t", onEnv),
  video = ffi.cast("retro_video_refresh_t", onVideo),
  a1 = ffi.cast("retro_audio_sample_t", onAudio1),
  ab = ffi.cast("retro_audio_sample_batch_t", onAudioBatch),
  poll = ffi.cast("retro_input_poll_t", onPoll),
  input = ffi.cast("retro_input_state_t", onInput),
}

local function internalDir()
  local f = io.open("/proc/self/cmdline", "rb")
  if not f then return nil end
  local s = f:read("*a"); f:close()
  local pkg = s:match("^[^%z]+")
  if not pkg then return nil end
  for _, d in ipairs({ "/data/data/" .. pkg .. "/files/", "/data/user/0/" .. pkg .. "/files/" }) do
    local t = io.open(d .. "t.tmp", "wb")
    if t then t:close(); os.remove(d .. "t.tmp"); return d end
  end
end

function S.findCore()
  local ext = ({ Windows = ".dll", OSX = ".dylib" })[ffi.os] or ".so"
  for _, d in ipairs({ "", "core", "ext" }) do
    for _, f in ipairs(love.filesystem.getDirectoryItems(d)) do
      local l = f:lower()
      if l:sub(-#ext) == ext then
        for _, h in ipairs(cfg.hints) do
          if l:find(h, 1, true) then return d == "" and f or (d .. "/" .. f) end
        end
      end
    end
  end
end

local function openCore()
  local f, cands = S.findCore(), {}
  local errs = { "archivo=" .. tostring(f) }
  if f then
    if love.system.getOS() == "Android" then
      local dir = internalDir()
      errs[#errs + 1] = "interno=" .. tostring(dir)
      local data = love.filesystem.read(f)
      if dir and data then
        local dest = dir .. cfg.id .. "_core.so"
        os.remove(dest)
        local fh = io.open(dest, "wb")
        if fh then
          fh:write(data); fh:close()
          pcall(function() ffi.C.chmod(dest, 292) end)
          cands[#cands + 1] = dest
        end
      end
    end
    cands[#cands + 1] = love.filesystem.getSaveDirectory() .. "/" .. f
  end
  if f then cands[#cands + 1] = love.filesystem.getSource() .. "/" .. f; cands[#cands + 1] = love.filesystem.getSourceBaseDirectory() .. "/" .. f end
  cands[#cands + 1] = cfg.bare
  for _, p in ipairs(cands) do
    local ok, lib = pcall(ffi.load, p)
    if ok then return lib end
    errs[#errs + 1] = p .. " -> " .. tostring(lib)
  end
  error("No pude cargar el core " .. cfg.id .. ":\n" .. table.concat(errs, "\n"), 0)
end

local function initCore()
  local sd = love.filesystem.getSaveDirectory()
  sysdirC = ffi.new("char[?]", #sd + 1); ffi.copy(sysdirC, sd)
  core = openCore()
  core.retro_set_environment(cbs.env)
  core.retro_set_video_refresh(cbs.video)
  core.retro_set_audio_sample(cbs.a1)
  core.retro_set_audio_sample_batch(cbs.ab)
  core.retro_set_input_poll(cbs.poll)
  core.retro_set_input_state(cbs.input)
  core.retro_init()
end

local romBuf
function S.load(data)
  love.filesystem.write("retro_log.txt", ""); logN = 0; S.aq = 0; S.fr = 0
  LOG("init " .. cfg.id .. " rom=" .. #data)
  if not core then initCore() end
  LOG("core ok")
  if S.loaded then S.stop() end
  romBuf = ffi.new("uint8_t[?]", #data); ffi.copy(romBuf, data, #data)
  local info = ffi.new("retro_game_info")
  info.path = cfg.path; info.data = romBuf; info.size = #data; info.meta = nil
  audioN = 0
  if not cfg.nodev then core.retro_set_controller_port_device(0, 1) end
  LOG("load_game")
  if not core.retro_load_game(info) then error("El core rechazo la ROM", 0) end
  local av = ffi.new("retro_system_av_info")
  core.retro_get_system_av_info(av)
  S.fps = av.timing.fps
  srate = math.floor(av.timing.sample_rate + 0.5)
  if av.geometry.aspect_ratio > 0 then S.aspect = av.geometry.aspect_ratio end
  src = love.audio.newQueueableSource(srate, 16, 2, 5)
  sdc, sdp, audioN, mask = {}, {}, 0, 0
  LOG("loaded ok fps=" .. av.timing.fps)
  S.loaded = true
end

function S.stop()
  if not S.loaded then return end
  if src then src:stop(); src = nil end
  audioN = 0
  core.retro_unload_game()
  S.image, S.w, S.h, S.loaded, audioN = nil, 0, 0, false, 0
end

local function flushAudio()
  if audioN == 0 or not src then audioN = 0; return end
  if src:getFreeBufferCount() > 0 then
    local sd = sdc[audioN]
    if not sd then
      sd = love.sound.newSoundData(audioN, srate, 16, 2)
      sdc[audioN], sdp[audioN] = sd, sd:getFFIPointer()
    end
    ffi.copy(sdp[audioN], audioBuf, audioN * 4)
    src:queue(sd)
    if not src:isPlaying() then src:play() end
    audioN = 0
  elseif audioN > CAP * 0.75 then audioN = 0 end   -- sin buffer libre: conserva muestras en vez de tirarlas
end

function S.setMask(m) mask = m end
function S.setAnalog(a, b, c, d) ax[1], ax[2], ax[3], ax[4] = a, b, c, d end
function S.getShader()
  shader = shader or love.graphics.newShader("vec4 effect(vec4 col, Image t, vec2 uv, vec2 sc){ vec4 c = Texel(t, uv); return vec4(c.b, c.g, c.r, 1.0) * col; }")
  return shader
end
local fr = 0
function S.frame(skip) fr = fr + 1; S.fr = S.fr + 1; if fr < 4 then LOG("frame " .. fr) end; skipV = skip; core.retro_run(); flushAudio() end
function S.pauseAudio() if src then src:pause() end end
function S.resumeAudio() if src then src:play() end end

function S.getSram()
  local sz = tonumber(core.retro_get_memory_size(2))
  local p = core.retro_get_memory_data(2)
  if sz > 0 and sz < 0x1000000 and p ~= nil then return ffi.string(p, sz) end
end
function S.setSram(d)
  local sz = tonumber(core.retro_get_memory_size(2))
  local p = core.retro_get_memory_data(2)
  if sz > 0 and p ~= nil then ffi.copy(p, d, math.min(#d, sz)) end
end
function S.getState()
  local n = tonumber(core.retro_serialize_size())
  local b = ffi.new("uint8_t[?]", n)
  if core.retro_serialize(b, n) then return ffi.string(b, n) end
end
function S.setState(d) return core.retro_unserialize(d, #d) end

return S
end
